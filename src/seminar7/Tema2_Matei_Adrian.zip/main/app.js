const distance = (a, b) => {
	if (typeof a !== 'string' && !(a instanceof String) || typeof b !== 'string' && !(b instanceof String)) {
		throw new Error('InvalidType')
	} else if (a === "" && b === "") {
		return 0;
	} else {
		if (!a.length) {
			return b.length;
		} else if (!b.length) {
			return a.length;
		} else {

			let mat = [];
			for (let i = 0; i <= b.length; i++) {
				mat[i] = [i];
			}

			for (let j = 0; j <= a.length; j++) {
				mat[0][j] = j;
			}

			for (let i = 1; i <= b.length; i++) {
				for (let j = 1; j <= a.length; j++) {
					if (b.charAt(i - 1) === a.charAt(j - 1)) {
						mat[i][j] = mat[i - 1][j - 1];
					} else {
						mat[i][j] = Math.min(mat[i - 1][j - 1] + 1,
							Math.min(mat[i][j - 1] + 1,
								mat[i - 1][j] + 1)); 
					}
				}
			}

			return mat[b.length][a.length];

		}

	}

}

let a = distance("masa", "caras");
console.log(a)

module.exports.distance = distance